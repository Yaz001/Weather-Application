namespace WeatherApplication.Models
{
    public class WeatherDataModel
    {
        public double Temperature { get; set; }
        public double Humidity { get; set; }
        public double WindSpeed { get; set; }
    }
}
